<?php $this->load->view('includes/front_header'); ?>

<?php $this->load->view($main_content); ?>

<?php $this->load->view('includes/front_footer'); ?>